class ExerciseModel {
  String name;
  String description;
  String lottieAssets;

  ExerciseModel(
      {required this.name,
      required this.description,
      required this.lottieAssets});
}
