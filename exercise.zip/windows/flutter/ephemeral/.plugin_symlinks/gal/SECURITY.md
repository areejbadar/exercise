# Security Policy

## Supported Versions

Support for `stable` and `beta` versions of flutter.

## Reporting a Vulnerability

Basically, you create an Issue.　

If it is a critical problem, you can send a DM to code owner.
