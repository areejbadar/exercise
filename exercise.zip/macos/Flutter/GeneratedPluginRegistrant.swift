//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import gal
import path_provider_foundation

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  GalPlugin.register(with: registry.registrar(forPlugin: "GalPlugin"))
  PathProviderPlugin.register(with: registry.registrar(forPlugin: "PathProviderPlugin"))
}
